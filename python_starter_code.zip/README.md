# Single-DeepSDF
Single-DeepSDF

- training:
    ```python
    python train.py
    ```

- testing:
    ```python
    python train.py -e
    ```
